import { useState, useEffect } from "react";

export default function Home() {
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (submitted) {
      const timer = setTimeout(() => setSubmitted(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [submitted]);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      {/* Hero Section */}
      <section className="bg-blue-600 text-white py-20 text-center">
        <h1 className="text-4xl font-bold mb-4">MHS Movements</h1>
        <p className="text-lg">
          Your trusted delivery & clearance experts across the East of England
        </p>
      </section>

      {/* Services Section */}
      <section className="py-16 px-6 grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        <div className="bg-white shadow-lg rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-2">Delivery Services</h2>
          <p>From small items to large furniture, we deliver safely and on time.</p>
        </div>
        <div className="bg-white shadow-lg rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-2">House & Office Clearance</h2>
          <p>Reliable, respectful, and eco-friendly clearance solutions.</p>
        </div>
        <div className="bg-white shadow-lg rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-2">Proof of Delivery</h2>
          <p>We provide photo confirmation and records for your peace of mind.</p>
        </div>
      </section>

      {/* Coverage */}
      <section className="bg-gray-100 py-16 px-6 text-center">
        <h2 className="text-2xl font-bold mb-4">Coverage</h2>
        <p>Based in Peterborough, we proudly cover the entire East of England.</p>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-6 max-w-4xl mx-auto text-center">
        <h2 className="text-2xl font-bold mb-8">What Our Customers Say</h2>
        <blockquote className="italic">
          “MHS Movements made my house move stress-free. Professional and quick!”
        </blockquote>
        <p className="mt-2 font-semibold">– Sarah J.</p>
      </section>

      {/* Quote Form */}
      <section className="bg-blue-50 py-16 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-6">Request a Free Quote</h2>
          {!submitted ? (
            <form
              action="https://formspree.io/f/mjkvgynd"
              method="POST"
              onSubmit={() => setSubmitted(true)}
              className="grid gap-4"
            >
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                required
                className="p-3 border rounded-xl"
              />
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                required
                className="p-3 border rounded-xl"
              />
              <textarea
                name="message"
                placeholder="Your Message"
                rows="4"
                required
                className="p-3 border rounded-xl"
              ></textarea>
              <button
                type="submit"
                className="bg-blue-600 text-white rounded-xl py-3"
              >
                Send Request
              </button>
            </form>
          ) : (
            <p className="text-green-600 font-semibold text-lg">
              ✅ Thank you! Your request has been sent. We'll get back to you
              shortly.
            </p>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gray-800 text-white py-16 px-6 text-center">
        <h2 className="text-2xl font-bold mb-4">Get in Touch</h2>
        <p className="mb-2">
          📞{" "}
          <a href="tel:07824922847" className="underline">
            07824 922847
          </a>
        </p>
        <p className="mb-2">
          📧{" "}
          <a
            href="mailto:mhsmovementcompany@gmail.com"
            className="underline"
          >
            mhsmovementcompany@gmail.com
          </a>
        </p>
        <p className="mb-6">
          💬{" "}
          <a href="https://wa.me/447824922847" className="underline">
            Chat on WhatsApp
          </a>
        </p>
        <p>© {new Date().getFullYear()} MHS Movements. All rights reserved.</p>
      </section>
    </div>
  );
}
